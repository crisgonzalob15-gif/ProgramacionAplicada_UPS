package vista;

import controlador.ControladorEmpleado;
import modelo.Administrativo;
import modelo.Obrero;
import modelo.Tecnico;

import javax.swing.*;

public class MenuPrincipal extends JFrame {
    private ControladorEmpleado controlador = new ControladorEmpleado();

    public MenuPrincipal() {
        setTitle("SISTEMA DE GESTIÓN DE EMPLEADOS");
        setSize(420, 320);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setLayout(null);

        JButton btnAdmin = new JButton("Registrar Administrativo");
        btnAdmin.setBounds(80, 30, 250, 30);
        getContentPane().add(btnAdmin);

        JButton btnObrero = new JButton("Registrar Obrero");
        btnObrero.setBounds(80, 75, 250, 30);
        getContentPane().add(btnObrero);

        JButton btnTecnico = new JButton("Registrar Técnico");
        btnTecnico.setBounds(80, 120, 250, 30);
        getContentPane().add(btnTecnico);

        JButton btnConsulta = new JButton("Consultar y Listar Empleados");
        btnConsulta.setBounds(80, 165, 250, 30);
        getContentPane().add(btnConsulta);

        JButton btnSalir = new JButton("Salir");
        btnSalir.setBounds(80, 210, 250, 30);
        getContentPane().add(btnSalir);

        btnAdmin.addActionListener(e -> abrirFormAdmin());
        btnObrero.addActionListener(e -> abrirFormObrero());
        btnTecnico.addActionListener(e -> abrirFormTecnico());
        btnConsulta.addActionListener(e -> abrirFormConsulta());
        btnSalir.addActionListener(e -> System.exit(0));
    }

    private void abrirFormAdmin() {
        JFrame f = new JFrame("Registro Administrativo");
        f.setSize(350, 220);
        f.setLocationRelativeTo(this);
        f.getContentPane().setLayout(null);

        JLabel l1 = new JLabel("Nombre:"); l1.setBounds(20, 20, 80, 25); f.add(l1);
        JTextField t1 = new JTextField(); t1.setBounds(110, 20, 180, 25); f.add(t1);

        JLabel l2 = new JLabel("Cédula:"); l2.setBounds(20, 60, 80, 25); f.add(l2);
        JTextField t2 = new JTextField(); t2.setBounds(110, 60, 180, 25); f.add(t2);

        JLabel l3 = new JLabel("Cargo:"); l3.setBounds(20, 100, 80, 25); f.add(l3);
        JTextField t3 = new JTextField(); t3.setBounds(110, 100, 180, 25); f.add(t3);

        JButton b = new JButton("Guardar");
        b.setBounds(110, 140, 100, 25);
        b.addActionListener(e -> {
            try {
                String nom = t1.getText().trim();
                String cedStr = t2.getText().trim();
                String car = t3.getText().trim();

                if (nom.isEmpty() || cedStr.isEmpty() || car.isEmpty()) {
                    JOptionPane.showMessageDialog(f, "Complete todos los campos", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (!cedStr.matches("\\d{10}")) {
                    JOptionPane.showMessageDialog(f, "La cédula debe ser de 10 dígitos numéricos", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                long ced = Long.parseLong(cedStr);
                if (controlador.registrarAdministrativo(nom, ced, car)) {
                    JOptionPane.showMessageDialog(f, "Administrativo registrado con éxito");
                    f.dispose();
                } else {
                    JOptionPane.showMessageDialog(f, "La cédula ya se encuentra registrada", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(f, "Datos incorrectos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        f.add(b);
        f.setVisible(true);
    }

    private void abrirFormObrero() {
        JFrame f = new JFrame("Registro Obrero");
        f.setSize(350, 220);
        f.setLocationRelativeTo(this);
        f.getContentPane().setLayout(null);

        JLabel l1 = new JLabel("Nombre:"); l1.setBounds(20, 20, 80, 25); f.add(l1);
        JTextField t1 = new JTextField(); t1.setBounds(110, 20, 180, 25); f.add(t1);

        JLabel l2 = new JLabel("Cédula:"); l2.setBounds(20, 60, 80, 25); f.add(l2);
        JTextField t2 = new JTextField(); t2.setBounds(110, 60, 180, 25); f.add(t2);

        JLabel l3 = new JLabel("Código:"); l3.setBounds(20, 100, 80, 25); f.add(l3);
        JTextField t3 = new JTextField(); t3.setBounds(110, 100, 180, 25); f.add(t3);

        JButton b = new JButton("Guardar");
        b.setBounds(110, 140, 100, 25);
        b.addActionListener(e -> {
            try {
                String nom = t1.getText().trim();
                String cedStr = t2.getText().trim();
                String cod = t3.getText().trim();

                if (nom.isEmpty() || cedStr.isEmpty() || cod.isEmpty()) {
                    JOptionPane.showMessageDialog(f, "Complete todos los campos", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (!cedStr.matches("\\d{10}")) {
                    JOptionPane.showMessageDialog(f, "La cédula debe ser de 10 dígitos numéricos", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                long ced = Long.parseLong(cedStr);
                if (controlador.registrarObrero(nom, ced, cod)) {
                    JOptionPane.showMessageDialog(f, "Obrero registrado con éxito");
                    f.dispose();
                } else {
                    JOptionPane.showMessageDialog(f, "La cédula ya se encuentra registrada", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(f, "Datos incorrectos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        f.add(b);
        f.setVisible(true);
    }

    private void abrirFormTecnico() {
        JFrame f = new JFrame("Registro Técnico");
        f.setSize(350, 250);
        f.setLocationRelativeTo(this);
        f.getContentPane().setLayout(null);

        JLabel l1 = new JLabel("Nombre:"); l1.setBounds(20, 20, 80, 25); f.add(l1);
        JTextField t1 = new JTextField(); t1.setBounds(110, 20, 180, 25); f.add(t1);

        JLabel l2 = new JLabel("Cédula:"); l2.setBounds(20, 60, 80, 25); f.add(l2);
        JTextField t2 = new JTextField(); t2.setBounds(110, 60, 180, 25); f.add(t2);

        JLabel l3 = new JLabel("Código:"); l3.setBounds(20, 100, 80, 25); f.add(l3);
        JTextField t3 = new JTextField(); t3.setBounds(110, 100, 180, 25); f.add(t3);

        JLabel l4 = new JLabel("Clave:"); l4.setBounds(20, 140, 80, 25); f.add(l4);
        JTextField t4 = new JTextField(); t4.setBounds(110, 140, 180, 25); f.add(t4);

        JButton b = new JButton("Guardar");
        b.setBounds(110, 180, 100, 25);
        b.addActionListener(e -> {
            try {
                String nom = t1.getText().trim();
                String cedStr = t2.getText().trim();
                String cod = t3.getText().trim();
                String clav = t4.getText().trim();

                if (nom.isEmpty() || cedStr.isEmpty() || cod.isEmpty() || clav.isEmpty()) {
                    JOptionPane.showMessageDialog(f, "Complete todos los campos", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (!cedStr.matches("\\d{10}")) {
                    JOptionPane.showMessageDialog(f, "La cédula debe ser de 10 dígitos numéricos", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                long ced = Long.parseLong(cedStr);
                if (controlador.registrarTecnico(nom, ced, cod, clav)) {
                    JOptionPane.showMessageDialog(f, "Técnico registrado con éxito");
                    f.dispose();
                } else {
                    JOptionPane.showMessageDialog(f, "La cédula ya se encuentra registrada", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(f, "Datos incorrectos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        f.add(b);
        f.setVisible(true);
    }

    private void abrirFormConsulta() {
        JFrame f = new JFrame("Consulta y Listado");
        f.setSize(450, 350);
        f.setLocationRelativeTo(this);
        f.getContentPane().setLayout(null);

        JLabel l1 = new JLabel("Cédula:"); l1.setBounds(20, 20, 60, 25); f.add(l1);
        JTextField t1 = new JTextField(); t1.setBounds(80, 20, 150, 25); f.add(t1);

        JButton bBuscar = new JButton("Buscar");
        bBuscar.setBounds(240, 20, 160, 25);
        bBuscar.addActionListener(e -> {
            try {
                long ced = Long.parseLong(t1.getText().trim());
                String res = controlador.consultarEmpleado(ced);
                if (res != null) {
                    JOptionPane.showMessageDialog(f, res, "Resultado", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(f, "Empleado no encontrado", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(f, "Cédula inválida", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        f.add(bBuscar);

        JTextArea area = new JTextArea();
        area.setEditable(false);
        JScrollPane scroll = new JScrollPane(area);
        scroll.setBounds(20, 60, 380, 200);
        f.add(scroll);

        JButton bListar = new JButton("Listar Todos");
        bListar.setBounds(150, 275, 130, 25);
        bListar.addActionListener(e -> {
            StringBuilder sb = new StringBuilder();
            sb.append("--- ADMINISTRATIVOS ---\n");
            for (Administrativo a : controlador.getRepoAdministrativos().listarTodos()) {
                sb.append(a.getNombre()).append(" | ").append(a.getCedula()).append(" | ").append(a.getCargo()).append("\n");
            }
            sb.append("\n--- OBREROS ---\n");
            for (Obrero o : controlador.getRepoObreros().listarTodos()) {
                sb.append(o.getNombre()).append(" | ").append(o.getCedula()).append(" | ").append(o.getCodigo()).append("\n");
            }
            sb.append("\n--- TÉCNICOS ---\n");
            for (Tecnico t : controlador.getRepoTecnicos().listarTodos()) {
                sb.append(t.getNombre()).append(" | ").append(t.getCedula()).append(" | ").append(t.getCodigo()).append(" | ").append(t.getClaveAcceso()).append("\n");
            }
            area.setText(sb.toString());
        });
        f.add(bListar);

        f.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MenuPrincipal().setVisible(true));
    }
}