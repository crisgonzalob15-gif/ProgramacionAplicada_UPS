package modelo;

public class Persona {
    private String nombre;
    private Long cedula; // Uso de clase envolvente (Boxing / Unboxing)

    public Persona(String nombre, long cedula) {
        this.nombre = nombre;
        this.cedula = Long.valueOf(cedula); // Boxing
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public long getCedula() {
        return cedula != null ? cedula.longValue() : 0L; // Unboxing
    }

    public void setCedula(long cedula) {
        this.cedula = Long.valueOf(cedula);
    }

    public void print(String texto) {
        System.out.println(texto);
    }

    public void informacion() {
        print("Información básica de la persona");
    }
}