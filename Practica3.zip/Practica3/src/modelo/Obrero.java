package modelo;

public class Obrero extends Persona {
    protected String codigo;

    public Obrero(String nombre, long cedula, String codigo) {
        super(nombre, cedula);
        this.codigo = codigo;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    @Override
    public void informacion() {
        print("OBRERO -> Nombre: " + getNombre() + " | Cédula: " + getCedula() + " | Código: " + codigo);
    }
}