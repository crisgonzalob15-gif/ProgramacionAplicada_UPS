package modelo;

import java.util.ArrayList;

public class Repositorio<T extends Persona> {
    private ArrayList<T> elementos = new ArrayList<>();

    public void agregar(T elemento) {
        elementos.add(elemento);
    }

    public T buscarPorCedula(long cedula) {
        for (int i = 0; i < elementos.size(); i++) {
            Integer index = Integer.valueOf(i); 
            T item = elementos.get(index.intValue()); 
            if (item.getCedula() == cedula) {
                return item;
            }
        }
        return null;
    }

    public ArrayList<T> listarTodos() {
        return elementos;
    }
}