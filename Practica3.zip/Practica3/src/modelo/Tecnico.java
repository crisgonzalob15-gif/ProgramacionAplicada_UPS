package modelo;

public class Tecnico extends Obrero {
    private String claveAcceso;

    public Tecnico(String nombre, long cedula, String codigo, String claveAcceso) {
        super(nombre, cedula, codigo);
        this.claveAcceso = claveAcceso;
    }

    public String getClaveAcceso() {
        return claveAcceso;
    }

    public void setClaveAcceso(String claveAcceso) {
        this.claveAcceso = claveAcceso;
    }

    @Override
    public void informacion() {
        print("TÉCNICO -> Nombre: " + getNombre() + " | Cédula: " + getCedula() + " | Código: " + codigo + " | Clave: " + claveAcceso);
    }
}