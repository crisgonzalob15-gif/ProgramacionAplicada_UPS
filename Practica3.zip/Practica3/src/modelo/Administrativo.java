package modelo;

public class Administrativo extends Persona {
    private String cargo;

    public Administrativo(String nombre, long cedula, String cargo) {
        super(nombre, cedula);
        this.cargo = cargo;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    @Override
    public void informacion() {
        print("ADMINISTRATIVO -> Nombre: " + getNombre() + " | Cédula: " + getCedula() + " | Cargo: " + cargo);
    }
}