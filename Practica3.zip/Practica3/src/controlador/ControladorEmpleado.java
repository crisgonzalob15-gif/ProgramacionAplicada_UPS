package controlador;

import modelo.Administrativo;
import modelo.Obrero;
import modelo.Repositorio;
import modelo.Tecnico;

public class ControladorEmpleado {
    private Repositorio<Administrativo> repoAdministrativos = new Repositorio<>();
    private Repositorio<Obrero> repoObreros = new Repositorio<>();
    private Repositorio<Tecnico> repoTecnicos = new Repositorio<>();

    public boolean registrarAdministrativo(String nombre, long cedula, String cargo) {
        if (buscarCedulaGlobal(cedula)) return false;
        repoAdministrativos.agregar(new Administrativo(nombre, cedula, cargo));
        return true;
    }

    public boolean registrarObrero(String nombre, long cedula, String codigo) {
        if (buscarCedulaGlobal(cedula)) return false;
        repoObreros.agregar(new Obrero(nombre, cedula, codigo));
        return true;
    }

    public boolean registrarTecnico(String nombre, long cedula, String codigo, String clave) {
        if (buscarCedulaGlobal(cedula)) return false;
        repoTecnicos.agregar(new Tecnico(nombre, cedula, codigo, clave));
        return true;
    }

    public boolean buscarCedulaGlobal(long cedula) {
        return repoAdministrativos.buscarPorCedula(cedula) != null ||
               repoObreros.buscarPorCedula(cedula) != null ||
               repoTecnicos.buscarPorCedula(cedula) != null;
    }

    public String consultarEmpleado(long cedula) {
        Administrativo a = repoAdministrativos.buscarPorCedula(cedula);
        if (a != null) return "[Administrativo] Nombre: " + a.getNombre() + " | Cédula: " + a.getCedula() + " | Cargo: " + a.getCargo();

        Obrero o = repoObreros.buscarPorCedula(cedula);
        if (o != null) return "[Obrero] Nombre: " + o.getNombre() + " | Cédula: " + o.getCedula() + " | Código: " + o.getCodigo() + " - Código: " + o.getCodigo();

        Tecnico t = repoTecnicos.buscarPorCedula(cedula);
        if (t != null) return "[Técnico] Nombre: " + t.getNombre() + " | Cédula: " + t.getCedula() + " | Código: " + t.getCodigo() + " | Clave: " + t.getClaveAcceso();

        return null;
    }

    public Repositorio<Administrativo> getRepoAdministrativos() { return repoAdministrativos; }
    public Repositorio<Obrero> getRepoObreros() { return repoObreros; }
    public Repositorio<Tecnico> getRepoTecnicos() { return repoTecnicos; }
}