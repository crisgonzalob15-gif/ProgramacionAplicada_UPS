package parqueadero;

import java.time.LocalDateTime;

public class Vehiculo {
    private String placa;
    private LocalDateTime ingreso;

    public Vehiculo(String placa, LocalDateTime ingreso) {
        this.placa = placa;
        this.ingreso = ingreso;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public LocalDateTime getIngreso() {
        return ingreso;
    }

    public void setIngreso(LocalDateTime ingreso) {
        this.ingreso = ingreso;
    }

    @Override
    public String toString() {
        return placa + "," + ingreso.toString();
    }
}