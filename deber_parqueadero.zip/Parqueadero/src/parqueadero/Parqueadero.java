package parqueadero;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

public class Parqueadero {
    private ParqueaderoDao dao;
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public Parqueadero() {
        this.dao = new ParqueaderoDao();
    }

    public String registrarIngreso(String placa) {
        placa = placa.trim().toUpperCase();
        if (placa.isEmpty()) {
            return "Error: La placa no puede estar vacía.";
        }

        List<Vehiculo> vehiculos = dao.obtenerVehiculos();
        for (Vehiculo v : vehiculos) {
            if (v.getPlaca().equals(placa)) {
                return "Error: El vehículo con placa " + placa + " ya se encuentra estacionado.";
            }
        }

        Vehiculo nuevo = new Vehiculo(placa, LocalDateTime.now());
        dao.guardarVehiculo(nuevo);
        return "Vehículo " + placa + " registrado con éxito a las " + nuevo.getIngreso().format(FORMATTER);
    }

    public String registrarSalida(String placa) {
        placa = placa.trim().toUpperCase();
        if (placa.isEmpty()) {
            return "Error: Ingrese una placa válida.";
        }

        List<Vehiculo> vehiculos = dao.obtenerVehiculos();
        Vehiculo vehiculoEncontrado = null;

        for (Vehiculo v : vehiculos) {
            if (v.getPlaca().equals(placa)) {
                vehiculoEncontrado = v;
                break;
            }
        }

        if (vehiculoEncontrado == null) {
            return "Error: No se encontró el vehículo con placa " + placa;
        }

        vehiculos.remove(vehiculoEncontrado);
        dao.actualizarVehiculos(vehiculos);

        LocalDateTime salida = LocalDateTime.now();
        long minutos = Duration.between(vehiculoEncontrado.getIngreso(), salida).toMinutes();
        if (minutos <= 0) minutos = 1;

        int fracciones = (int) Math.ceil(minutos / 60.0);
        double totalPagar = fracciones * 0.50;

        String transaccion = placa + "," + 
                             vehiculoEncontrado.getIngreso().format(FORMATTER) + "," + 
                             salida.format(FORMATTER) + "," + 
                             String.format(Locale.US, "%.2f", totalPagar);
        dao.guardarTransaccion(transaccion);

        return "=== TICKET DE SALIDA ===\n" +
               "Placa: " + placa + "\n" +
               "Ingreso: " + vehiculoEncontrado.getIngreso().format(FORMATTER) + "\n" +
               "Salida: " + salida.format(FORMATTER) + "\n" +
               "Tiempo: " + minutos + " min (" + fracciones + " hora(s) o fracción)\n" +
               String.format(Locale.US, "Total a Cancelar: $%.2f", totalPagar);
    }

    public List<Vehiculo> getVehiculosEstacionados() {
        return dao.obtenerVehiculos();
    }

    public List<String> getHistorialCaja() {
        return dao.obtenerTransacciones();
    }
}