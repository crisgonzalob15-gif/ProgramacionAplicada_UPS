package parqueadero;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class ParqueaderoVentana extends JFrame {
    private Parqueadero parqueadero;
    
    private JTextField txtPlacaIngreso;
    private JTextField txtPlacaSalida;
    private JTextArea txtAreaTicket;
    private JTable tablaVehiculos;
    private DefaultTableModel modeloVehiculos;
    private JTable tablaCaja;
    private DefaultTableModel modeloCaja;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                ParqueaderoVentana frame = new ParqueaderoVentana();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public ParqueaderoVentana() {
        parqueadero = new Parqueadero();
        setTitle("Sistema de Gestión de Parqueadero - GUI");
        setSize(750, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setLayout(new BorderLayout());

        JTabbedPane tabbedPane = new JTabbedPane();
        getContentPane().add(tabbedPane, BorderLayout.CENTER);

        // --- PESTAÑA 1: INGRESO ---
        JPanel panelIngreso = new JPanel();
        panelIngreso.setLayout(null);
        
        JLabel lblPlacaIn = new JLabel("Placa del Vehículo:");
        lblPlacaIn.setBounds(180, 120, 130, 25);
        panelIngreso.add(lblPlacaIn);

        txtPlacaIngreso = new JTextField();
        txtPlacaIngreso.setBounds(310, 120, 160, 25);
        panelIngreso.add(txtPlacaIngreso);

        JButton btnIngresar = new JButton("Registrar Ingreso");
        btnIngresar.setBounds(260, 180, 180, 35);
        panelIngreso.add(btnIngresar);

        tabbedPane.addTab("Ingreso", panelIngreso);

        // --- PESTAÑA 2: SALIDA Y COBRO ---
        JPanel panelSalida = new JPanel();
        panelSalida.setLayout(null);

        JLabel lblPlacaOut = new JLabel("Placa:");
        lblPlacaOut.setBounds(30, 30, 50, 25);
        panelSalida.add(lblPlacaOut);

        txtPlacaSalida = new JTextField();
        txtPlacaSalida.setBounds(80, 30, 140, 25);
        panelSalida.add(txtPlacaSalida);

        JButton btnSalida = new JButton("Procesar Salida y Cobro");
        btnSalida.setBounds(240, 30, 190, 25);
        panelSalida.add(btnSalida);

        txtAreaTicket = new JTextArea();
        txtAreaTicket.setEditable(false);
        JScrollPane scrollTicket = new JScrollPane(txtAreaTicket);
        scrollTicket.setBounds(30, 80, 670, 320);
        panelSalida.add(scrollTicket);

        tabbedPane.addTab("Salida y Cobro", panelSalida);

        // --- PESTAÑA 3: VEHÍCULOS ESTACIONADOS ---
        JPanel panelVehiculos = new JPanel(new BorderLayout());
        modeloVehiculos = new DefaultTableModel(new String[]{"Placa", "Hora de Ingreso"}, 0);
        tablaVehiculos = new JTable(modeloVehiculos);
        panelVehiculos.add(new JScrollPane(tablaVehiculos), BorderLayout.CENTER);

        JButton btnActualizarVehiculos = new JButton("Actualizar Lista");
        panelVehiculos.add(btnActualizarVehiculos, BorderLayout.SOUTH);

        tabbedPane.addTab("Vehículos Estacionados", panelVehiculos);

        // --- PESTAÑA 4: CAJA Y RECAUDACIÓN ---
        JPanel panelCaja = new JPanel(new BorderLayout());
        modeloCaja = new DefaultTableModel(new String[]{"Placa", "Ingreso", "Salida", "Pago ($)"}, 0);
        tablaCaja = new JTable(modeloCaja);
        panelCaja.add(new JScrollPane(tablaCaja), BorderLayout.CENTER);

        JButton btnActualizarCaja = new JButton("Actualizar Historial de Caja");
        panelCaja.add(btnActualizarCaja, BorderLayout.SOUTH);

        tabbedPane.addTab("Caja / Historial", panelCaja);

     // --- EVENTOS ---
        btnIngresar.addActionListener(e -> {
            String resultado = parqueadero.registrarIngreso(txtPlacaIngreso.getText());
            JOptionPane.showMessageDialog(this, resultado);
            txtPlacaIngreso.setText("");
            cargarVehiculosEstacionados();
        });

        btnSalida.addActionListener(e -> {
            String resultado = parqueadero.registrarSalida(txtPlacaSalida.getText());
            txtAreaTicket.setText(resultado);
            txtPlacaSalida.setText("");
            cargarVehiculosEstacionados();
            cargarCaja();
        });

        btnActualizarVehiculos.addActionListener(e -> cargarVehiculosEstacionados());
        btnActualizarCaja.addActionListener(e -> cargarCaja());

        cargarVehiculosEstacionados();
        cargarCaja();
    }

    private void cargarVehiculosEstacionados() {
        modeloVehiculos.setRowCount(0);
        List<Vehiculo> lista = parqueadero.getVehiculosEstacionados();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        for (Vehiculo v : lista) {
            modeloVehiculos.addRow(new Object[]{v.getPlaca(), v.getIngreso().format(formatter)});
        }
    }

    private void cargarCaja() {
        modeloCaja.setRowCount(0);
        List<String> transacciones = parqueadero.getHistorialCaja();
        for (String t : transacciones) {
            String[] partes = t.split(",");
            if (partes.length >= 4) {
                modeloCaja.addRow(new Object[]{partes[0], partes[1], partes[2], partes[3]});
            }
        }
    }
}