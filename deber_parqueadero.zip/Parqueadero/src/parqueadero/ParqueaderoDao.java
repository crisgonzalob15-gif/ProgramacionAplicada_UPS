package parqueadero;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class ParqueaderoDao {
    private static final String ARCHIVO_VEHICULOS = "vehiculos.txt";
    private static final String ARCHIVO_CAJA = "caja.txt";
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public void guardarVehiculo(Vehiculo vehiculo) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ARCHIVO_VEHICULOS, true))) {
            writer.write(vehiculo.getPlaca() + "," + vehiculo.getIngreso().format(FORMATTER));
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Error al guardar vehículo: " + e.getMessage());
        }
    }

    public List<Vehiculo> obtenerVehiculos() {
        List<Vehiculo> lista = new ArrayList<>();
        File archivo = new File(ARCHIVO_VEHICULOS);
        if (!archivo.exists()) return lista;

        try (BufferedReader reader = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length >= 2) {
                    String placa = partes[0];
                    LocalDateTime ingreso = LocalDateTime.parse(partes[1], FORMATTER);
                    lista.add(new Vehiculo(placa, ingreso));
                }
            }
        } catch (IOException e) {
            System.err.println("Error al leer vehículos: " + e.getMessage());
        }
        return lista;
    }

    public void actualizarVehiculos(List<Vehiculo> vehiculos) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ARCHIVO_VEHICULOS, false))) {
            for (Vehiculo v : vehiculos) {
                writer.write(v.getPlaca() + "," + v.getIngreso().format(FORMATTER));
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error al actualizar archivo de vehículos: " + e.getMessage());
        }
    }

    public void guardarTransaccion(String transaccion) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ARCHIVO_CAJA, true))) {
            writer.write(transaccion);
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Error al guardar transacción en caja: " + e.getMessage());
        }
    }

    public List<String> obtenerTransacciones() {
        List<String> lista = new ArrayList<>();
        File archivo = new File(ARCHIVO_CAJA);
        if (!archivo.exists()) return lista;

        try (BufferedReader reader = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                lista.add(linea);
            }
        } catch (IOException e) {
            System.err.println("Error al leer caja: " + e.getMessage());
        }
        return lista;
    }
}
