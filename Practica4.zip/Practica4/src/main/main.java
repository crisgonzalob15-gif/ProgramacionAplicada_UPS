package main;

import vista.ConsolaVista;

public class main {
    public static void main(String[] args) {
        ConsolaVista vista = new ConsolaVista();
        vista.iniciarMenu();
    }
}