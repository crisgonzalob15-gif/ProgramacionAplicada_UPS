package modelo;

public class Aportador {
    private String cedula;
    private String correo;
    private String montoStr;
    private double monto;
    private boolean cedulaValida;
    private boolean correoValido;
    private boolean montoValido;

    public Aportador(String cedula, String correo, String montoStr) {
        this.cedula = cedula != null ? cedula.trim() : "";
        this.correo = correo != null ? correo.trim() : "";
        this.montoStr = montoStr != null ? montoStr.trim() : "";
        validarDatos();
    }

    public void validarDatos() {
        this.cedulaValida = cedula.matches("\\d{10}");

        this.correoValido = correo.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");

        try {
            String limpio = montoStr.replace("$", "").replace("dólares", "").replace("USD", "").trim();
            this.monto = Double.parseDouble(limpio);
            this.montoValido = (this.monto > 0);
        } catch (Exception e) {
            this.monto = 0.0;
            this.montoValido = false;
        }
    }

    public boolean esValido() {
        return cedulaValida && correoValido && montoValido;
    }

    // Getters
    public String getCedula() { return cedula; }
    public String getCorreo() { return correo; }
    public String getMontoStr() { return montoStr; }
    public double getMonto() { return monto; }
    public boolean isCedulaValida() { return cedulaValida; }
    public boolean isCorreoValido() { return correoValido; }
    public boolean isMontoValido() { return montoValido; }

    @Override
    public String toString() {
        String estCedula = cedulaValida ? "OK" : "ERR(Cédula)";
        String estCorreo = esValido() ? "OK" : "ERR(Correo)";
        String estMonto = montoValido ? "OK" : "ERR(Monto)";
        return String.format("Cédula: %-12s | Correo: %-30s | Monto: %-10s | Validación: [%s, %s, %s]",
                cedula, correo, montoStr, estCedula, estCorreo, estMonto);
    }
}