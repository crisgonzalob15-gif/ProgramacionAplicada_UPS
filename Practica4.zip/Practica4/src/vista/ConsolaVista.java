package vista;

import controlador.TesoreriaControlador;
import modelo.Aportador;
import java.util.Scanner;

public class ConsolaVista {
    private TesoreriaControlador controlador;
    private Scanner scanner;

    public ConsolaVista() {
        this.controlador = new TesoreriaControlador();
        this.scanner = new Scanner(System.in);
    }

    public void iniciarMenu() {
        int opcion = 0;
        do {
            System.out.println("\n==================================================");
            System.out.println("   SISTEMA DE ANÁLISIS DE INGRESOS - PRÁCTICA 4    ");
            System.out.println("==================================================");
            System.out.println("1. Cargar y procesar archivo (registro_ingresos.txt)");
            System.out.println("2. Ver listado de aportadores y validaciones");
            System.out.println("3. Ver resumen de ingresos válidos y errores");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");

            try {
                opcion = Integer.parseInt(scanner.nextLine());
                switch (opcion) {
                    case 1:
                        controlador.procesarArchivo();
                        break;
                    case 2:
                        mostrarListado();
                        break;
                    case 3:
                        mostrarResumen();
                        break;
                    case 4:
                        System.out.println("Saliendo del sistema. ¡Buen trabajo!");
                        break;
                    default:
                        System.out.println("Opción inválida. Intente de nuevo.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Por favor, ingrese un número válido.");
            }
        } while (opcion != 4);
    }

    public void mostrarListado() {
        var lista = controlador.getAportadores();
        if (lista.isEmpty()) {
            System.out.println("No hay registros cargados. Ejecute primero la opción 1.");
            return;
        }

        System.out.println("\n--- LISTADO GENERAL DE APORTADORES ---");
        int index = 1;
        for (Aportador ap : lista) {
            System.out.println(index++ + ". " + ap.toString());
        }
    }

    public void mostrarResumen() {
        var lista = controlador.getAportadores();
        if (lista.isEmpty()) {
            System.out.println("No hay registros cargados. Ejecute primero la opción 1.");
            return;
        }

        double totalValido = controlador.calcularTotalValido();
        int errCedulas = controlador.contarErroresCedulas();
        int errCorreos = controlador.contarErroresCorreos();
        int errMontos = controlador.contarErroresMontos();

        System.out.println("\n==================================================");
        System.out.println("         RESUMEN FINANCIERO Y DE ERRORES          ");
        System.out.println("==================================================");
        System.out.printf(" Total de ingresos válidos: $%.2f\n", totalValido);
        System.out.println("--------------------------------------------------");
        System.out.println(" RECUENTO DE ERRORES DETECTADOS:");
        System.out.println(" - Cédulas incorrectas:      " + errCedulas);
        System.out.println(" - Correos electrónicos con error: " + errCorreos);
        System.out.println(" - Montos monetarios con error:    " + errMontos);
        System.out.println("==================================================");
    }
}