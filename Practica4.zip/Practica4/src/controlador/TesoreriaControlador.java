package controlador;

import modelo.Aportador;
import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TesoreriaControlador {
    private ArrayList<Aportador> aportadores;
    private String nombreArchivo = "registro_ingresos.txt";

    public TesoreriaControlador() {
        this.aportadores = new ArrayList<>();
        crearArchivoSiNoExiste();
    }

    public void crearArchivoSiNoExiste() {
        File archivo = new File(nombreArchivo);
        if (!archivo.exists()) {
            try (PrintWriter pw = new PrintWriter(archivo)) {
                pw.println("REGISTRO DE INGRESOS DEL TESORERO");
                pw.println("Mes de noviembre de 2026");
                pw.println("El lunes 2 de noviembre recibí el aporte de Juan Carlos Pérez, cédula 1723456789, correo juan.perez@gmail.com, quien entregó $150.00 para el fondo común.");
                pw.println("También anoté que María Fernanda López, con cédula 1712345678 y correo maria.lopez@hotmail.com, dejó registrado un ingreso de 200 dólares.");
                pw.println("Ese mismo día Pedro Sánchez, CI 1724567890, correo pedro.sanchez@gmail.com, aportó 75.50 USD.");
                pw.println("Martes 3 de noviembre: llegó Andrés Molina, su cédula es 1723456781 y su correo andres.molina@gmail.com, dejó $120.00.");
                pw.println("Después llegó una persona llamada Carolina Torres, cédula 1719876543, correo carolina.torres.com, entregó 85 dólares.");
                pw.println("Anoté también a Roberto Díaz, cédula 1725678901, correo roberto.diaz@gmail.com, quien ingresó 300 dólares.");
                pw.println("El señor Luis Herrera dejó 50.00 $, su cédula 1726789012 y su correo luis.herrera@gmail.com.");
                pw.println("Miércoles 4 de noviembre, casi olvido registrar a Gabriela Ruiz, CI 1727890123, correo gabriela.ruiz@gmail.com, aportó $95.00.");
                pw.println("También estuvo presente Fernando Castro, cédula 1728901234, correo fernando.castro@gmail.com, entregó 110 dólares.");
                pw.println("Más tarde recibí de Daniela Vega, cédula 1729012345, correo daniela.vega@gmail.com, la cantidad de $45.75.");
                pw.println("El registro de Miguel Ángel, cédula 12345678, correo miguel.angel@gmail.com, indica que dejó 60 dólares.");
                pw.println("Jueves 5 de noviembre: Paola Cárdenas, cédula 1730123456, correo paola.cardenas@gmail.com, dejó $180.00.");
                pw.println("Jorge Ramírez, CI 1731234567, correo jorge.ramirez@gmail.com, entregó 90 dólares.");
                pw.println("Anoté rápidamente el ingreso de Verónica Flores, cédula 1732345678, correo veronica.flores@gmail.com, por $125.50.");
                pw.println("También llegó Esteban Morales, cédula 1733456789, correo esteban.morales@gmail.com, aportó 70 dólares.");
                pw.println("Viernes 6 de noviembre, recibí de Natalia Romero, cédula 1734567890, correo natalia.romero@gmail.com, $210.00.");
                pw.println("Luego apareció un registro de Santiago Ortiz, cédula 1735678901, correo santiagooritzyahoo.com, aportó 55 dólares.");
                pw.println("Cristina León, cédula 1736789012, correo cristina.leon@gmail.com, ingresó $135.00.");
                pw.println("El señor Diego Paredes, CI 1737890123, correo diego.paredes@gmail.com, entregó 80 dólares.");
                pw.println("Sábado 7 de noviembre: Ana Belén Ruiz, cédula 1738901234, correo ana.ruiz@gmail.com, aportó $160.00.");
                pw.println("Recibí también a Pablo Jiménez, cédula 1739012345, correo pablo.jimenez@gmail.com, quien dejó 40 dólares.");
                pw.println("El registro de Sofía Andrade, cédula 173012345, correo sofia.andrade@gmail.com, muestra un aporte de $65.00.");
                pw.println("Después anoté a Ricardo Núñez, cédula 1741234567, correo ricardo.nunez@gmail.com, con un ingreso de 250 dólares.");
                pw.println("Domingo 8 de noviembre, se acercó Mónica Salazar, cédula 1742345678, correo monica.salazar@gmail.com, entregó $115.00.");
                pw.println("También registré a Javier Cevallos, cédula 1743456789, correo javier.cevallos@gmail.com, aportó 100 dólares.");
                pw.println("Me parece que anoté mal el correo de Patricia Gómez, cédula 1744567890, correo patricia@@gmail.com, quien entregó 90 dólares.");
                pw.println("El señor Felipe Arias, cédula 1745678901, correo felipe.arias@gmail.com, dejó $175.25.");
                pw.println("Lunes 9 de noviembre: recibí de Teresa Molina, cédula 1746789012, correo teresa.molina@gmail.com, la cantidad de 0 dólares.");
                pw.println("También llegó Óscar Benítez, cédula 1747890123, correo oscar.benitez@gmail.com, dejó $220.00.");
                pw.println("Finalmente, anoté a Ricardo Vera, cédula 1748901234, correo ricardo.vera@gmail.com, quien entregó 145 dólares.");
                pw.println("Me falta confirmar el último registro: Gabriela Torres, cédula 1749012345, correo gabriela.torres@gmail.com, ingresó $80.50.");
            } catch (Exception e) {
                System.out.println("Error al crear el archivo: " + e.getMessage());
            }
        }
    }

    public void procesarArchivo() {
        aportadores.clear();
        File archivo = new File(nombreArchivo);
        if (!archivo.exists()) {
            System.out.println("El archivo de registro no existe.");
            return;
        }

        Pattern patronCedula = Pattern.compile("(?:cédula|CI|es)\\s*(?:es)?\\s*:?\\s*(\\w+)");
        Pattern patronCorreo = Pattern.compile("(?:correo|su correo)\\s*:?\\s*([^\\s,]+)");
        Pattern patronMonto = Pattern.compile("(\\$?\\s*\\d+(?:\\.\\d+)?\\s*(?:dólares|USD|\\$)?)");

        try (Scanner scanner = new Scanner(archivo)) {
            while (scanner.hasNextLine()) {
                String linea = scanner.nextLine();

                Matcher matcherCedula = patronCedula.matcher(linea);
                Matcher matcherCorreo = patronCorreo.matcher(linea);
                Matcher matcherMonto = patronMonto.matcher(linea);

                String cedula = matcherCedula.find() ? matcherCedula.group(1) : null;
                String correo = matcherCorreo.find() ? matcherCorreo.group(1).replace(",", "") : null;
                
                String montoStr = null;
                while (matcherMonto.find()) {
                    String candidato = matcherMonto.group(1).trim();
                    if (candidato.contains("$") || candidato.contains("dólares") || candidato.contains("USD") || candidato.matches(".*\\d+.*")) {
                        montoStr = candidato;
                        break;
                    }
                }

                if (cedula != null || correo != null || montoStr != null) {
                    Aportador ap = new Aportador(cedula, correo, montoStr);
                    aportadores.add(ap);
                }
            }
            System.out.println("¡Archivo procesado con éxito! Total de registros leídos: " + aportadores.size());
        } catch (Exception e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    }

    public ArrayList<Aportador> getAportadores() {
        return aportadores;
    }

    public double calcularTotalValido() {
        double total = 0;
        for (Aportador ap : aportadores) {
            if (ap.esValido()) {
                total += ap.getMonto();
            }
        }
        return total;
    }

    public int contarErroresCedulas() {
        int count = 0;
        for (Aportador ap : aportadores) {
            if (!ap.isCedulaValida()) count++;
        }
        return count;
    }

    public int contarErroresCorreos() {
        int count = 0;
        for (Aportador ap : aportadores) {
            if (!ap.isCorreoValido()) count++;
        }
        return count;
    }

    public int contarErroresMontos() {
        int count = 0;
        for (Aportador ap : aportadores) {
            if (!ap.isMontoValido()) count++;
        }
        return count;
    }
}