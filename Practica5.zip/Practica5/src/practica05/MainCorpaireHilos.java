package practica05;

import java.util.ArrayList;
import java.util.List;

public class MainCorpaireHilos {
    private static final int AUTOS_POR_MECANICO = 5;
    private static final String ARCHIVO_MECANICOS = "mecanicos.txt";
    private static final String ARCHIVO_VEHICULOS = "vehiculos.txt";

    public static void main(String[] args) {
        System.out.println("Iniciando sistema de revisión vehicular Corpaire (Quito)...");

        GestorArchivos.asegurarArchivosBase(ARCHIVO_MECANICOS, ARCHIVO_VEHICULOS);

        List<String> mecanicos = GestorArchivos.leerMecanicos(ARCHIVO_MECANICOS);
        List<String[]> vehiculos = GestorArchivos.leerVehiculos(ARCHIVO_VEHICULOS);

        if (mecanicos.isEmpty() || vehiculos.isEmpty()) {
            System.out.println("No hay suficientes datos en mecanicos.txt o vehiculos.txt.");
            return;
        }

        List<Thread> hilos = new ArrayList<>();
        int indiceVehiculo = 0;

        for (int i = 0; i < mecanicos.size(); i++) {
            String mecanico = mecanicos.get(i);
            List<String[]> loteAsignado = new ArrayList<>();

            for (int j = 0; j < AUTOS_POR_MECANICO; j++) {
                if (indiceVehiculo < vehiculos.size()) {
                    loteAsignado.add(vehiculos.get(indiceVehiculo));
                    indiceVehiculo++;
                } else {
                    loteAsignado.add(vehiculos.get(indiceVehiculo % vehiculos.size()));
                    indiceVehiculo++;
                }
            }

            Runnable tarea = new TareaRevisionMecanico(mecanico, loteAsignado);
            Thread hilo = new Thread(tarea, "Hilo-Mecanico-" + (i + 1));
            hilos.add(hilo);
            hilo.start();
        }

        for (Thread hilo : hilos) {
            try {
                hilo.join();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.err.println("Error esperando al hilo: " + hilo.getName());
            }
        }

        System.out.println("\nReporte diario de revisión vehicular completado para todos los mecánicos.");
    }
}