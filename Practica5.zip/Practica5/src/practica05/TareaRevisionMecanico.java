package practica05;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;

public class TareaRevisionMecanico implements Runnable {
    private static final Object LOCK_IMPRESION = new Object();

    private final String nombreMecanico;
    private final List<String[]> asignacionVehiculos;

    public TareaRevisionMecanico(String nombreMecanico, List<String[]> asignacionVehiculos) {
        this.nombreMecanico = nombreMecanico;
        this.asignacionVehiculos = asignacionVehiculos;
    }

    @Override
    public void run() {
        try {
            long demoraMs = ThreadLocalRandom.current().nextLong(500, 3001);
            Thread.sleep(demoraMs);

            List<Vehiculo> loteRevisado = new ArrayList<>();
            int totalLecturas = 0;
            int fallasLambda = 0;
            int fallasO2 = 0;
            int fallasN2o = 0;
            int fallasCo2 = 0;
            int totalFallasParametros = 0;

            for (String[] datosVehiculo : asignacionVehiculos) {
                String marca = datosVehiculo[0];
                String placa = datosVehiculo[1];

                double lambda = redondear(ThreadLocalRandom.current().nextDouble(0.75, 1.45), 2);
                double o2 = redondear(ThreadLocalRandom.current().nextDouble(0.5, 3.5), 2);
                double n2o = redondear(ThreadLocalRandom.current().nextDouble(10.0, 55.0), 2);
                double co2 = redondear(ThreadLocalRandom.current().nextDouble(5.0, 22.0), 2);

                Vehiculo v = new Vehiculo(marca, placa, lambda, o2, n2o, co2);
                loteRevisado.add(v);

                totalLecturas += 4;
                if (v.fallaLambda()) fallasLambda++;
                if (v.fallaO2()) fallasO2++;
                if (v.fallaN2o()) fallasN2o++;
                if (v.fallaCo2()) fallasCo2++;
                totalFallasParametros += v.cantidadFallas();
            }

            int cantidadAutos = loteRevisado.size();
            double pctErrorLote = cantidadAutos > 0
                    ? (totalFallasParametros * 100.0) / totalLecturas
                    : 0.0;

            double pctLambda = cantidadAutos > 0 ? (fallasLambda * 100.0) / cantidadAutos : 0.0;
            double pctO2 = cantidadAutos > 0 ? (fallasO2 * 100.0) / cantidadAutos : 0.0;
            double pctN2o = cantidadAutos > 0 ? (fallasN2o * 100.0) / cantidadAutos : 0.0;
            double pctCo2 = cantidadAutos > 0 ? (fallasCo2 * 100.0) / cantidadAutos : 0.0;

            boolean dentroToleranciasGases =
                    pctLambda <= 70.0 &&
                    pctO2 <= 30.0 &&
                    pctN2o <= 80.0 &&
                    pctCo2 <= 50.0;

            boolean apruebaLote = dentroToleranciasGases && pctErrorLote <= 50.0;
            String estadoLote = apruebaLote
                    ? "Pasa en Primera Revisión"
                    : "Segunda Revisión Asignada";

            imprimirTablaMecanico(
                    demoraMs,
                    loteRevisado,
                    pctLambda,
                    pctO2,
                    pctN2o,
                    pctCo2,
                    pctErrorLote,
                    estadoLote
            );

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.err.println("Hilo interrumpido para el mecánico " + nombreMecanico);
        }
    }

    private void imprimirTablaMecanico(
            long demoraMs,
            List<Vehiculo> lote,
            double pctLambda,
            double pctO2,
            double pctN2o,
            double pctCo2,
            double pctErrorLote,
            String estadoLote
    ) {
        synchronized (LOCK_IMPRESION) {
            StringBuilder sb = new StringBuilder();
            sb.append("\n====================================================================================================\n");
            sb.append(String.format(Locale.US,
                    "MECÁNICO: %-22s | HILO: %-24s | TIEMPO CARGA: %4d ms%n",
                    nombreMecanico, Thread.currentThread().getName(), demoraMs));
            sb.append("====================================================================================================\n");
            sb.append(String.format("%-12s | %-10s | %-8s | %-8s | %-8s | %-8s | %-28s%n",
                    "MARCA", "PLACA", "LAMBDA", "O2", "N2O", "CO2", "ESTADO VEHÍCULO"));
            sb.append("----------------------------------------------------------------------------------------------------\n");

            for (Vehiculo v : lote) {
                String estadoAuto = v.tieneAlgunaFalla()
                        ? "Segunda Revisión Asignada"
                        : "Pasa en Primera Revisión";

                sb.append(String.format(Locale.US,
                        "%-12s | %-10s | %-8.2f | %-8.2f | %-8.2f | %-8.2f | %-28s%n",
                        v.getMarca(), v.getPlaca(), v.getLambda(), v.getO2(), v.getN2o(), v.getCo2(), estadoAuto));
            }

            sb.append("----------------------------------------------------------------------------------------------------\n");
            sb.append(String.format(Locale.US,
                    "%% Falla por parámetro -> Lambda: %5.1f%% (tol. 70%%) | O2: %5.1f%% (tol. 30%%) | N2O: %5.1f%% (tol. 80%%) | CO2: %5.1f%% (tol. 50%%)%n",
                    pctLambda, pctO2, pctN2o, pctCo2));
            sb.append(String.format(Locale.US,
                    "%% DE ERRORES DEL LOTE A SER ARREGLADOS: %.2f%%%n", pctErrorLote));
            sb.append(String.format("RESULTADO REVISIÓN VEHICULAR (CORPAIRE) DEL LOTE: %s%n", estadoLote));
            sb.append("====================================================================================================\n");

            System.out.print(sb.toString());
        }
    }

    private double redondear(double valor, int decimales) {
        double factor = Math.pow(10, decimales);
        return Math.round(valor * factor) / factor;
    }
}