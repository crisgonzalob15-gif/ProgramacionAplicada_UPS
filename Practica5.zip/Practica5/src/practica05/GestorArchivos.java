package practica05;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GestorArchivos {

    public static void asegurarArchivosBase(String rutaMecanicos, String rutaVehiculos) {
        File archivoMec = new File(rutaMecanicos);
        if (!archivoMec.exists()) {
            String[] mecanicosDefault = {
                "Carlos Andrade",
                "Luis Cevallos",
                "Diego Viteri",
                "Andrés Paredes",
                "Jorge Morales",
                "Santiago Herrera",
                "Mateo Salazar",
                "Fernando Jácome",
                "Christian López",
                "Paúl Benítez"
            };
            try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivoMec))) {
                for (String m : mecanicosDefault) {
                    bw.write(m);
                    bw.newLine();
                }
            } catch (IOException e) {
                System.err.println("Error al crear mecanicos.txt: " + e.getMessage());
            }
        }

        File archivoVeh = new File(rutaVehiculos);
        if (!archivoVeh.exists()) {
            String[] marcas = {
                "Toyota", "Hyundai", "Chevrolet", "Kia", "Nissan",
                "Mazda", "Volkswagen", "Ford", "Renault", "Suzuki"
            };
            try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivoVeh))) {
                int contadorPlaca = 1001;
                for (int i = 0; i < 50; i++) {
                    String marca = marcas[i % marcas.length];
                    String placa = "PCH-" + (contadorPlaca + i);
                    bw.write(marca + ";" + placa);
                    bw.newLine();
                }
            } catch (IOException e) {
                System.err.println("Error al crear vehiculos.txt: " + e.getMessage());
            }
        }
    }

    public static List<String> leerMecanicos(String rutaArchivo) {
        List<String> mecanicos = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                linea = linea.trim();
                if (!linea.isEmpty()) {
                    mecanicos.add(linea);
                }
            }
        } catch (IOException e) {
            System.err.println("Error leyendo " + rutaArchivo + ": " + e.getMessage());
        }
        return mecanicos;
    }

    public static List<String[]> leerVehiculos(String rutaArchivo) {
        List<String[]> vehiculos = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                linea = linea.trim();
                if (!linea.isEmpty()) {
                    String[] partes = linea.split("[,;]");
                    if (partes.length >= 2) {
                        vehiculos.add(new String[]{partes[0].trim(), partes[1].trim()});
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error leyendo " + rutaArchivo + ": " + e.getMessage());
        }
        return vehiculos;
    }
}