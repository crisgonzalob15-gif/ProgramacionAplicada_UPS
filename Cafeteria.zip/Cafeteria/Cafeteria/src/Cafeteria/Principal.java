package Cafeteria;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Producto> listaProductos = new ArrayList<>();
        ArrayList<String> historialVentas = new ArrayList<>();
        
        String archivoProductos = "productos.txt";
        String archivoVentas = "ventas.txt";
        
        cargarProductos(listaProductos, archivoProductos);
        
        int opcion = 0;
        do {
            System.out.println("\n========================================");
            System.out.println("   CAFETERÍA UNIVERSITARIA 'EL BUEN SABOR'");
            System.out.println("========================================");
            System.out.println("1. Registrar Producto");
            System.out.println("2. Listar Catálogo de Productos");
            System.out.println("3. Reponer Stock de Producto");
            System.out.println("4. Registrar Pedido");
            System.out.println("5. Ver Reporte de Ventas");
            System.out.println("6. Guardar y Salir");
            System.out.print("Seleccione una opción: ");
            
            if(scanner.hasNextInt()) {
                opcion = scanner.nextInt();
                scanner.nextLine(); 
            } else {
                System.out.println("Por favor, ingrese un número válido.");
                scanner.nextLine();
                continue;
            }
            
            switch(opcion) {
                case 1:
                    System.out.print("Ingrese código del producto: ");
                    String codigo = scanner.nextLine();
                    System.out.print("Ingrese nombre del producto: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Ingrese precio unitario ($): ");
                    double precio = scanner.nextDouble();
                    System.out.print("Ingrese stock inicial: ");
                    int stock = scanner.nextInt();
                    scanner.nextLine();
                    
                    Producto nuevo = new Producto(codigo, nombre, precio, stock);
                    listaProductos.add(nuevo);
                    guardarProductos(listaProductos, archivoProductos);
                    System.out.println("¡Producto registrado y guardado con éxito!");
                    break;
                    
                case 2:
                    System.out.println("\n--- CATÁLOGO DE PRODUCTOS ---");
                    if(listaProductos.isEmpty()) {
                        System.out.println("No hay productos registrados actualmente.");
                    } else {
                        for(Producto p : listaProductos) {
                            System.out.println(p);
                        }
                    }
                    break;
                    
                case 3:
                    System.out.print("Ingrese el código del producto a reponer: ");
                    String codReponer = scanner.nextLine();
                    boolean encontrado = false;
                    for(Producto p : listaProductos) {
                        if(p.codigo.equalsIgnoreCase(codReponer)) {
                            System.out.print("Ingrese la cantidad adicional para el stock: ");
                            int cant = scanner.nextInt();
                            scanner.nextLine();
                            p.stock += cant;
                            guardarProductos(listaProductos, archivoProductos);
                            System.out.println("¡Stock actualizado con éxito!");
                            encontrado = true;
                            break;
                        }
                    }
                    if(!encontrado) {
                        System.out.println("Producto no encontrado en el catálogo.");
                    }
                    break;
                    
                case 4:
                    System.out.println("\n--- REGISTRAR PEDIDO ---");
                    if(listaProductos.isEmpty()) {
                        System.out.println("No hay productos disponibles para realizar pedidos.");
                        break;
                    }
                    double totalPedido = 0;
                    String detalleVenta = "Pedido: ";
                    boolean continuarComprando = true;
                    
                    while(continuarComprando) {
                        System.out.print("Ingrese el código del producto que desea comprar: ");
                        String codCompra = scanner.nextLine();
                        Producto prodComprar = null;
                        for(Producto p : listaProductos) {
                            if(p.codigo.equalsIgnoreCase(codCompra)) {
                                prodComprar = p;
                                break;
                            }
                        }
                        
                        if(prodComprar == null) {
                            System.out.println("Código de producto no válido.");
                        } else {
                            System.out.print("Cantidad a llevar (Stock disponible: " + prodComprar.stock + "): ");
                            int cantidad = scanner.nextInt();
                            scanner.nextLine();
                            
                            if(cantidad <= 0) {
                                System.out.println("Cantidad no válida.");
                            } else if(cantidad > prodComprar.stock) {
                                System.out.println("¡Stock insuficiente! No se puede completar la venta de este producto.");
                            } else {
                                prodComprar.stock -= cantidad;
                                double subtotal = prodComprar.precio * cantidad;
                                totalPedido += subtotal;
                                detalleVenta += "[" + prodComprar.nombre + " x " + cantidad + " ($" + subtotal + ")] ";
                                System.out.println("Producto agregado. Subtotal parcial: $" + subtotal);
                            }
                        }
                        
                        System.out.print("¿Desea agregar otro producto al pedido? (s/n): ");
                        String respuesta = scanner.nextLine();
                        if(respuesta.equalsIgnoreCase("n")) {
                            continuarComprando = false;
                        }
                    }
                    
                    if(totalPedido > 0) {
                        detalleVenta = detalleVenta + " | Total Pagado: $" + totalPedido;
                        historialVentas.add(detalleVenta);
                        guardarVentas(historialVentas, archivoVentas);
                        guardarProductos(listaProductos, archivoProductos); 
                        System.out.println("¡Pedido registrado con éxito! Total a cancelar: $" + totalPedido);
                    } else {
                        System.out.println("No se agregaron productos al pedido.");
                    }
                    break;
                    
                case 5:
                    System.out.println("\n--- REPORTE DE VENTAS ---");
                    if(historialVentas.isEmpty()) {
                        System.out.println("No hay ventas registradas todavía.");
                    } else {
                        for(String venta : historialVentas) {
                            System.out.println(venta);
                        }
                    }
                    break;
                    
                case 6:
                    guardarProductos(listaProductos, archivoProductos);
                    guardarVentas(historialVentas, archivoVentas);
                    System.out.println("Saliendo del sistema... ¡Gracias por usar el software de la cafetería!");
                    break;
                    
                default:
                    System.out.println("Opción no válida. Por favor, elija un número del 1 al 6.");
            }
            
        } while(opcion != 6);
        scanner.close();
    }
    
    public static void guardarProductos(ArrayList<Producto> lista, String nombreArchivo) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(nombreArchivo))) {
            for(Producto p : lista) {
                pw.println(p.codigo + ";" + p.nombre + ";" + p.precio + ";" + p.stock);
            }
        } catch(Exception e) {
            System.out.println("Error al guardar productos: " + e.getMessage());
        }
    }
    
    public static void cargarProductos(ArrayList<Producto> lista, String nombreArchivo) {
        File archivo = new File(nombreArchivo);
        if(!archivo.exists()) return;
        try (Scanner lector = new Scanner(archivo)) {
            lista.clear();
            while(lector.hasNextLine()) {
                String linea = lector.nextLine();
                String[] partes = linea.split(";");
                if(partes.length == 4) {
                    String codigo = partes[0];
                    String nombre = partes[1];
                    double precio = Double.parseDouble(partes[2]);
                    int stock = Integer.parseInt(partes[3]);
                    lista.add(new Producto(codigo, nombre, precio, stock));
                }
            }
        } catch(Exception e) {
            System.out.println("Error al cargar productos: "+ e.getMessage());
        }
    }
    
    public static void guardarVentas(ArrayList<String> ventas, String nombreArchivo) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(nombreArchivo))) {
            for(String v : ventas) {
                pw.println(v);
            }
        } catch(Exception e) {
            System.out.println("Error al guardar ventas: "+ e.getMessage());
        }
    }
}