package Cafeteria;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class Principal extends JFrame {
    
    private ArrayList<Producto> listaProductos = new ArrayList<>();
    private ArrayList<String> historialVentas = new ArrayList<>();
    
    private String archivoProductos = "productos.txt";
    private String archivoVentas = "ventas.txt";

    private JTable tablaProductos;
    private DefaultTableModel modeloTablaProductos;
    
    private JTextField txtCodigo, txtNombre, txtPrecio, txtStock, txtCodReponer, txtCantReponer;
    private JTextField txtCodCompra, txtCantCompra;
    private JTextArea txtAreaReporte;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Principal frame = new Principal();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Principal() {
        cargarProductos(listaProductos, archivoProductos);
        cargarVentas(historialVentas, archivoVentas);

        setTitle("Cafetería Universitaria 'El Buen Sabor' - Versión 2.0 GUI");
        setSize(750, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setLayout(new BorderLayout());

        JTabbedPane tabbedPane = new JTabbedPane();
        getContentPane().add(tabbedPane, BorderLayout.CENTER);

        JPanel panelProductos = new JPanel(new BorderLayout());
        
        modeloTablaProductos = new DefaultTableModel(new String[]{"Código", "Nombre", "Precio ($", "Stock"}, 0);
        tablaProductos = new JTable(modeloTablaProductos);
        panelProductos.add(new JScrollPane(tablaProductos), BorderLayout.CENTER);

        JPanel panelFormulario = new JPanel(new GridLayout(5, 2, 5, 5));
        panelFormulario.add(new JLabel(" Código:"));
        txtCodigo = new JTextField();
        panelFormulario.add(txtCodigo);
        
        panelFormulario.add(new JLabel(" Nombre:"));
        txtNombre = new JTextField();
        panelFormulario.add(txtNombre);
        
        panelFormulario.add(new JLabel(" Precio Unitario ($):"));
        txtPrecio = new JTextField();
        panelFormulario.add(txtPrecio);
        
        panelFormulario.add(new JLabel(" Stock Inicial:"));
        txtStock = new JTextField();
        panelFormulario.add(txtStock);

        JButton btnRegistrar = new JButton("Registrar Producto");
        panelFormulario.add(btnRegistrar);
        
        JButton btnActualizarTabla = new JButton("Actualizar Catálogo");
        panelFormulario.add(btnActualizarTabla);

        panelProductos.add(panelFormulario, BorderLayout.SOUTH);
        tabbedPane.addTab("Catálogo y Registro", panelProductos);

        JPanel panelStock = new JPanel(null);
        
        JLabel lblCodR = new JLabel("Código de Producto:");
        lblCodR.setBounds(50, 60, 150, 25);
        panelStock.add(lblCodR);
        txtCodReponer = new JTextField();
        txtCodReponer.setBounds(200, 60, 150, 25);
        panelStock.add(txtCodReponer);

        JLabel lblCantR = new JLabel("Cantidad a Sumar:");
        lblCantR.setBounds(50, 110, 150, 25);
        panelStock.add(lblCantR);
        txtCantReponer = new JTextField();
        txtCantReponer.setBounds(200, 110, 150, 25);
        panelStock.add(txtCantReponer);

        JButton btnReponer = new JButton("Reponer Stock");
        btnReponer.setBounds(150, 170, 180, 35);
        panelStock.add(btnReponer);

        tabbedPane.addTab("Reponer Stock", panelStock);

        JPanel panelPedido = new JPanel(null);
        
        JLabel lblCodC = new JLabel("Código de Producto:");
        lblCodC.setBounds(40, 40, 140, 25);
        panelPedido.add(lblCodC);
        txtCodCompra = new JTextField();
        txtCodCompra.setBounds(180, 40, 140, 25);
        panelPedido.add(txtCodCompra);

        JLabel lblCantC = new JLabel("Cantidad a Llevar:");
        lblCantC.setBounds(40, 80, 140, 25);
        panelPedido.add(lblCantC);
        txtCantCompra = new JTextField();
        txtCantCompra.setBounds(180, 80, 140, 25);
        panelPedido.add(txtCantCompra);

        JButton btnComprar = new JButton("Procesar Pedido / Venta");
        btnComprar.setBounds(110, 130, 200, 35);
        panelPedido.add(btnComprar);

        tabbedPane.addTab("Registrar Pedido", panelPedido);

        JPanel panelReportes = new JPanel(new BorderLayout());
        txtAreaReporte = new JTextArea();
        txtAreaReporte.setEditable(false);
        panelReportes.add(new JScrollPane(txtAreaReporte), BorderLayout.CENTER);

        JButton btnVerReporte = new JButton("Actualizar Reporte de Ventas");
        panelReportes.add(btnVerReporte, BorderLayout.SOUTH);

        tabbedPane.addTab("Reporte de Ventas", panelReportes);

        btnRegistrar.addActionListener(e -> {
            try {
                String codigo = txtCodigo.getText().trim();
                String nombre = txtNombre.getText().trim();
                double precio = Double.parseDouble(txtPrecio.getText().trim());
                int stock = Integer.parseInt(txtStock.getText().trim());

                if(codigo.isEmpty() || nombre.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                Producto nuevo = new Producto(codigo, nombre, precio, stock);
                listaProductos.add(nuevo);
                guardarProductos(listaProductos, archivoProductos);
                actualizarTabla();

                JOptionPane.showMessageDialog(this, "¡Producto registrado con éxito!");
                txtCodigo.setText("");
                txtNombre.setText("");
                txtPrecio.setText("");
                txtStock.setText("");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Ingrese valores numéricos válidos en precio y stock.", "Error de formato", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnActualizarTabla.addActionListener(e -> actualizarTabla());

        btnReponer.addActionListener(e -> {
            try {
                String cod = txtCodReponer.getText().trim();
                int cant = Integer.parseInt(txtCantReponer.getText().trim());
                boolean encontrado = false;

                for (Producto p : listaProductos) {
                    if (p.codigo.equalsIgnoreCase(cod)) {
                        p.stock += cant;
                        guardarProductos(listaProductos, archivoProductos);
                        actualizarTabla();
                        encontrado = true;
                        JOptionPane.showMessageDialog(this, "¡Stock actualizado con éxito!");
                        txtCodReponer.setText("");
                        txtCantReponer.setText("");
                        break;
                    }
                }
                if (!encontrado) {
                    JOptionPane.showMessageDialog(this, "Producto no encontrado.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Ingrese una cantidad numérica válida.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnComprar.addActionListener(e -> {
            try {
                String cod = txtCodCompra.getText().trim();
                int cantidad = Integer.parseInt(txtCantCompra.getText().trim());
                Producto prodComprar = null;

                for (Producto p : listaProductos) {
                    if (p.codigo.equalsIgnoreCase(cod)) {
                        prodComprar = p;
                        break;
                    }
                }

                if (prodComprar == null) {
                    JOptionPane.showMessageDialog(this, "Código de producto no válido.", "Error", JOptionPane.ERROR_MESSAGE);
                } else if (cantidad <= 0) {
                    JOptionPane.showMessageDialog(this, "Cantidad no válida.", "Error", JOptionPane.ERROR_MESSAGE);
                } else if (cantidad > prodComprar.stock) {
                    JOptionPane.showMessageDialog(this, "¡Stock insuficiente! Stock disponible: " + prodComprar.stock, "Advertencia", JOptionPane.WARNING_MESSAGE);
                } else {
                    prodComprar.stock -= cantidad;
                    double subtotal = prodComprar.precio * cantidad;
                    String detalleVenta = "Pedido: [" + prodComprar.nombre + " x " + cantidad + " ($" + subtotal + ")] | Total Pagado: $" + subtotal;
                    
                    historialVentas.add(detalleVenta);
                    guardarVentas(historialVentas, archivoVentas);
                    guardarProductos(listaProductos, archivoProductos);
                    actualizarTabla();
                    actualizarReporteTexto();

                    JOptionPane.showMessageDialog(this, "¡Pedido registrado con éxito! Total a cancelar: $" + subtotal);
                    txtCodCompra.setText("");
                    txtCantCompra.setText("");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Ingrese una cantidad numérica válida.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnVerReporte.addActionListener(e -> actualizarReporteTexto());

        actualizarTabla();
        actualizarReporteTexto();
    }

    private void actualizarTabla() {
        modeloTablaProductos.setRowCount(0);
        for (Producto p : listaProductos) {
            modeloTablaProductos.addRow(new Object[]{p.codigo, p.nombre, "$" + p.precio, p.stock});
        }
    }

    private void actualizarReporteTexto() {
        StringBuilder sb = new StringBuilder();
        if (historialVentas.isEmpty()) {
            sb.append("No hay ventas registradas todavía.");
        } else {
            for (String v : historialVentas) {
                sb.append(v).append("\n");
            }
        }
        txtAreaReporte.setText(sb.toString());
    }

    public static void guardarProductos(ArrayList<Producto> lista, String nombreArchivo) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(nombreArchivo))) {
            for (Producto p : lista) {
                pw.println(p.codigo + ";" + p.nombre + ";" + p.precio + ";" + p.stock);
            }
        } catch (Exception e) {
            System.out.println("Error al guardar productos: " + e.getMessage());
        }
    }

    public static void cargarProductos(ArrayList<Producto> lista, String nombreArchivo) {
        File archivo = new File(nombreArchivo);
        if (!archivo.exists()) return;
        try (Scanner lector = new Scanner(archivo)) {
            lista.clear();
            while (lector.hasNextLine()) {
                String linea = lector.nextLine();
                String[] partes = linea.split(";");
                if (partes.length == 4) {
                    String codigo = partes[0];
                    String nombre = partes[1];
                    double precio = Double.parseDouble(partes[2]);
                    int stock = Integer.parseInt(partes[3]);
                    lista.add(new Producto(codigo, nombre, precio, stock));
                }
            }
        } catch (Exception e) {
            System.out.println("Error al cargar productos: " + e.getMessage());
        }
    }

    public static void guardarVentas(ArrayList<String> ventas, String nombreArchivo) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(nombreArchivo))) {
            for (String v : ventas) {
                pw.println(v);
            }
        } catch (Exception e) {
            System.out.println("Error al guardar ventas: " + e.getMessage());
        }
    }

    public static void cargarVentas(ArrayList<String> ventas, String nombreArchivo) {
        File archivo = new File(nombreArchivo);
        if (!archivo.exists()) return;
        try (Scanner lector = new Scanner(archivo)) {
            ventas.clear();
            while (lector.hasNextLine()) {
                ventas.add(lector.nextLine());
            }
        } catch (Exception e) {
            System.out.println("Error al cargar ventas: " + e.getMessage());
        }
    }
}